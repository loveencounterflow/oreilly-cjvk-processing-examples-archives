/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 *
 * April 1994
 *
 */
extern int eval(const unsigned char *expression_string);

#define EVAL_OK                    0
#define EVAL_SYNTAX                1
#define EVAL_DIVZERO               2
#define EVAL_EOS                   3
#define EVAL_NOSYM                 4
#define EVAL_UNMATCHED_CLOSE       5
#define EVAL_UNMATCHED_OPEN        6

#define EVAL_MAX_ERROR EVAL_UNMATCHED_OPEN
extern int eval_error_val;
extern const unsigned char *eval_errstr[];
extern const unsigned char *eval_error_loc;
