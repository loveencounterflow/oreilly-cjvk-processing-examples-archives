/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 */
#define PATCHLEVEL 3 /* patchlevel off the major version number */
const char version_string[] = "Version 1.06";
const char version_date  [] = "Nov 8, 1995";
const char compile_date  [] =  __DATE__;
const char author_name   [] = "Jeffrey Friedl";
const char contact_addr  [] = "jfriedl@omron.co.jp";
