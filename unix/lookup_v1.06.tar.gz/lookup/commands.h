/*
 *
 *  This file generated from (and by) the file "cmds.master".
 *
 */

#define S const unsigned char *


/* generated from "cmds.master", record at line 92 */
static int _func3_(void)
{
  return cmd_do_search(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 98 */
static int _func4_(void)
{
  return cmd_set_local_autokana_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 104 */
static int _func5_(void)
{
  return cmd_set_default_autokana_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 116 */
static int _func7_(void)
{
  return cmd_cmdchar(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 122 */
static int _func8_(void)
{
  return cmd_set_default_cmd_debug_flag(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 128 */
static int _func9_(void)
{
  return cmd_combine(cmd_paren[4-1], cmd_paren[5-1] ? atoi(cmd_paren[5-1]) : -1, cmd_paren[6-1]);
}

/* generated from "cmds.master", record at line 134 */
static int _func10_(void)
{
  return cmd_set_default_debug_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 140 */
static int _func11_(void)
{
  return cmd_describe_raw(cmd_paren[2-1]);;
}

/* generated from "cmds.master", record at line 146 */
static int _func12_(void)
{
  return cmd_describe_raw(cmd_paren[1-1]);;
}

/* generated from "cmds.master", record at line 152 */
static int _func13_(void)
{
  return cmd_describe_kuten(cmd_paren[2-1]);;
}

/* generated from "cmds.master", record at line 158 */
static int _func14_(void)
{
  return cmd_describe_ascii(8, cmd_paren[2-1]);;
}

/* generated from "cmds.master", record at line 164 */
static int _func15_(void)
{
  return cmd_describe_ascii(10, cmd_paren[1-1]);;
}

/* generated from "cmds.master", record at line 170 */
static int _func16_(void)
{
  return cmd_describe_ascii(16, cmd_paren[1-1]);;
}

/* generated from "cmds.master", record at line 176 */
static int _func17_(void)
{
  return cmd_describe_encoding(cmd_paren[1-1], cmd_paren[3-1]);;
}

/* generated from "cmds.master", record at line 182 */
static int _func18_(void)
{
  return cmd_describe_jis_string(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 188 */
static int _func19_(void)
{
  return cmd_set_local_display_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 194 */
static int _func20_(void)
{
  return cmd_set_default_display_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 200 */
static int _func21_(void)
{
  return cmd_encoding(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 206 */
static int _func22_(void)
{
  return cmd_list_files(cmd_paren[2-1] ? 1 : 0);
}

/* generated from "cmds.master", record at line 212 */
static int _func23_(void)
{
  return cmd_filter(cmd_paren[5-1], cmd_paren[2-1], cmd_paren[3-1][0] == '!', cmd_paren[6-1][0] == 'i');
}

/* generated from "cmds.master", record at line 218 */
static int _func24_(void)
{
  return cmd_toggle_filter(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 224 */
static int _func25_(void)
{
  return cmd_set_local_fold_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 230 */
static int _func26_(void)
{
  return cmd_set_default_fold_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 236 */
static int _func27_(void)
{
  return cmd_set_local_fuzz_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 242 */
static int _func28_(void)
{
  return cmd_set_default_fuzz_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 248 */
static int _func29_(void)
{
  return cmd_help(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 254 */
static int _func30_(void)
{
  return cmd_set_local_highlight_flag(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 260 */
static int _func31_(void)
{
  return cmd_set_highlighting_style(cmd_paren[4-1]);
}

/* generated from "cmds.master", record at line 266 */
static int _func32_(void)
{
  return cmd_if(cmd_paren[1-1],cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 272 */
static int _func33_(void)
{
  return cmd_set_default_highlight_flag(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 278 */
static int _func34_(void)
{
  return cmd_input_encoding(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 284 */
static int _func35_(void)
{
  return cmd_set_limit(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 290 */
static int _func36_(void)
{
  return cmd_load((const char *)cmd_paren[4-1], cmd_paren[2-1] ? 1 : 0);
}

/* generated from "cmds.master", record at line 296 */
static int _func37_(void)
{
  return cmd_log(cmd_paren[2-1] ? 1 : 0, cmd_paren[5-1] ? 1 : 0, cmd_paren[7-1]);
}

/* generated from "cmds.master", record at line 302 */
static int _func38_(void)
{
  return cmd_modify(cmd_paren[2-1],cmd_paren[3-1], cmd_paren[4-1][0] == 'i' || cmd_paren[4-1][1] == 'i', cmd_paren[4-1][0] == 'g' || cmd_paren[4-1][1] == 'g');
}

/* generated from "cmds.master", record at line 308 */
static int _func39_(void)
{
  return cmd_toggle_modify(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 314 */
static int _func40_(void)
{
  return cmd_msg(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 320 */
static int _func41_(void)
{
  return cmd_output_encoding(cmd_paren[2-1], cmd_paren[3-1], cmd_paren[5-1], cmd_paren[6-1]);
}

/* generated from "cmds.master", record at line 326 */
static int _func42_(void)
{
  return cmd_pager(cmd_paren[2-1], cmd_paren[4-1], cmd_paren[5-1]);
}

/* generated from "cmds.master", record at line 332 */
static int _func43_(void)
{
  return cmd_set_prompt(1, cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 338 */
static int _func44_(void)
{
  return cmd_set_prompt(0, cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 344 */
static int _func45_(void)
{
  return cmd_set_default_regex_debug_flag(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 350 */
static int _func46_(void)
{
  return cmd_list_size(cmd_paren[5-1]);
}

/* generated from "cmds.master", record at line 356 */
static int _func47_(void)
{
  return cmd_select(cmd_paren[4-1], (const char *)cmd_paren[7-1], cmd_paren[2-1] ? 1 : 0);
}

/* generated from "cmds.master", record at line 368 */
static int _func49_(void)
{
  return cmd_source((const char *)cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 374 */
static int _func50_(void)
{
  return cmd_set_spinner(cmd_paren[2-1]);
}

/* generated from "cmds.master", record at line 386 */
static int _func52_(void)
{
  return cmd_tag(cmd_paren[1-1], cmd_paren[4-1]);
}

/* generated from "cmds.master", record at line 392 */
static int _func53_(void)
{
  return set_verbose_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 404 */
static int _func55_(void)
{
  return cmd_set_local_word_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 410 */
static int _func56_(void)
{
  return cmd_set_default_word_flag(cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 416 */
static int _func57_(void)
{
  return cmd_set_local_glob_flag(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 422 */
static int _func58_(void)
{
  return cmd_set_default_glob_flag(cmd_paren[3-1]);
}

/* generated from "cmds.master", record at line 434 */
static int _func60_(void)
{
  return cmd_error("expecting argument", cmd_paren[1-1]);
}

/* generated from "cmds.master", record at line 440 */
static int _func61_(void)
{
  return cmd_error("argument error", cmd_paren[2-1]);
}

static struct command command[] = {

    /* generated from "cmds.master" record at line 80*/
    {
        CMD_FILE_ONLY /* comment line */,
        (S)0,
        (S)0,
        (S)"^\\s*#",
         0,
    },

    /* generated from "cmds.master" record at line 86*/
    {
        CMD_FILE_ONLY /* blank line */,
        (S)0,
        (S)0,
        (S)"^\\s*$",
         0,
    },

    /* generated from "cmds.master" record at line 92*/
    {
        CMD_FILE_ONLY /* search */,
        (S)0,
        (S)0,
        (S)"^\\s*([+!=].*)",
         _func3_,
    },

    /* generated from "cmds.master" record at line 98*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] autokana [on|1|off|0]",
        (S)"Turns automatic romaji conversion on or off, or reports current status.",
        (S)"^\\s*default\\s*autokana>\\s*(on|1|off|0)?\\s*$",
         _func4_,
    },

    /* generated from "cmds.master" record at line 104*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*autokana>\\s*(on|1|off|0)?\\s*$",
         _func5_,
    },

    /* generated from "cmds.master" record at line 110*/
    {
        CMD_GENERAL,
        (S)"clear|cls",
        (S)"clear the screen",
        (S)"^\\s*(clear|cls)\\s*$",
         cmd_clear,
    },

    /* generated from "cmds.master" record at line 116*/
    {
        CMD_GENERAL,
        (S)"cmdchar ['bytechar']",
        (S)"set the this-is-a-command character",
        (S)"^\\s*cmd(char)?\\s*('(\\a)')?\\s*$",
         _func7_,
    },

    /* generated from "cmds.master" record at line 122*/
    {
        CMD_GENERAL,
        (S)"command debug [on|1|off|0]",
        (S)"Turns command debugging on or off, or reports current status.",
        (S)"^\\s*c(om(mand)?)?>\\s*debug>\\s*(on|1|off|0)?\\s*$",
         _func8_,
    },

    /* generated from "cmds.master" record at line 128*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED,
        (S)"combine> [\"name\"] [num =] num [num....]",
        (S)"Combines previously-loaded slots to one new slot.",
        (S)"^\\s*comb(o|ine)\\s*(([\"'])(.*)\\3\\s*=?)?\\s*(\\d+\\s*\\+?=)?\\s*((#?\\s*\\d+\\s*,?\\s*)+)\\s*$",
         _func9_,
    },

    /* generated from "cmds.master" record at line 134*/
    {
        CMD_GENERAL,
        (S)"debug [on|1|off|0]",
        (S)"Turns debugging on or off, or reports current status.",
        (S)"^\\s*debug>\\s*(on|1|off|0)?\\s*$",
         _func10_,
    },

    /* generated from "cmds.master" record at line 140*/
    {
        CMD_GENERAL,
        (S)"describe \"string\"|character|[kuten|euc|jis|sjis|ascii]code",
        (S)"describes the encodings for the character(s) indicated",
        (S)"^\\s*describe>\\s*(['\"])(.*)\\1\\s*$",
         _func11_,
    },

    /* generated from "cmds.master" record at line 146*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe>\\s*(\\A+|[!-~])\\s*$",
         _func12_,
    },

    /* generated from "cmds.master" record at line 152*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe>\\s*(kuten>\\s*)?(\\d\\d\\d\\d)\\s*$",
         _func13_,
    },

    /* generated from "cmds.master" record at line 158*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe\\s*ascii\\s*(\\\\|0)([0-7]+)\\s*$",
         _func14_,
    },

    /* generated from "cmds.master" record at line 164*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe\\s*ascii\\s*(\\d+)\\s*$",
         _func15_,
    },

    /* generated from "cmds.master" record at line 170*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe\\s*ascii\\s*(0[xX])?([0-9a-f][0-9a-f])\\s*$",
         _func16_,
    },

    /* generated from "cmds.master" record at line 176*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe>\\s*(sjis>|jis>|euc>)?\\s*(0[xX])?(<[0-9a-f][0-9a-f][0-9a-f][0-9a-f]>)\\s*$",
         _func17_,
    },

    /* generated from "cmds.master" record at line 182*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*describe>\\s*(\\$@|\\$B|\\$@\\$B)?(([!-~][!-~])+)(\\(\\$@|\\$B|\\$@\\$B|\\$\\(D|\\(J|\\(H|\\(B|\\(I)?\\s*$",
         _func18_,
    },

    /* generated from "cmds.master" record at line 188*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] display [on|1|off|0]",
        (S)"Turns display of matching lines on or off.",
        (S)"^\\s*display>\\s*(on|1|off|0)?\\s*$",
         _func19_,
    },

    /* generated from "cmds.master" record at line 194*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*display>\\s*(on|1|off|0)?\\s*$",
         _func20_,
    },

    /* generated from "cmds.master" record at line 200*/
    {
        CMD_GENERAL|CMD_ENCODING_RELATED,
        (S)"encoding (euc|jis|sjis)",
        (S)"set the input/output encoding-method",
        (S)"^\\s*encod(e|ing)>\\s*(euc|jis|sjis)?\\s*$",
         _func21_,
    },

    /* generated from "cmds.master" record at line 206*/
    {
        CMD_GENERAL,
        (S)"files|slots [-]",
        (S)"list what files are loaded into what slots.",
        (S)"^\\s*(slot|file)s?>\\s*(-|-?(help|long))?\\s*$",
         _func22_,
    },

    /* generated from "cmds.master" record at line 212*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED,
        (S)"filter [\"name\"] [!] /regex/[i]",
        (S)"set the filter for the selected file.",
        (S)"^\\s*filter>\\s*(\"([^\"]*)\")?\\s*(!?)\\s*(\\S)(.+)\\4(i?)\\s*$",
         _func23_,
    },

    /* generated from "cmds.master" record at line 218*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"filter [on|1|off|0]",
        (S)"turn the filter (for the selected file) on or off, or report its status",
        (S)"^\\s*filter>\\s*(on|1|off|0)?\\s*$",
         _func24_,
    },

    /* generated from "cmds.master" record at line 224*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] fold [on|1|off|0]",
        (S)"Turns case folding on or off, or reports current status.",
        (S)"^\\s*fold>\\s*(on|1|off|0)?\\s*$",
         _func25_,
    },

    /* generated from "cmds.master" record at line 230*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*fold>\\s*(on|1|off|0)?\\s*$",
         _func26_,
    },

    /* generated from "cmds.master" record at line 236*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] fuzz [on|1|off|0]",
        (S)"Turns fuzzification on or off, or reports current status.",
        (S)"^\\s*fuzz>\\s*(on|1|off|0)?\\s*$",
         _func27_,
    },

    /* generated from "cmds.master" record at line 242*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*fuzz>\\s*(on|1|off|0)?\\s*$",
         _func28_,
    },

    /* generated from "cmds.master" record at line 248*/
    {
        CMD_GENERAL,
        (S)"help [string]",
        (S)"list help",
        (S)"^\\s*help\\s*(.*\\S)?\\s*$",
         _func29_,
    },

    /* generated from "cmds.master" record at line 254*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] highlight [on|1|off|0]",
        (S)"Turns highlighting on or off, or reports current status.",
        (S)"^\\s*h(igh)?l(ight)?>\\s*(on|1|off|0)?\\s*$",
         _func30_,
    },

    /* generated from "cmds.master" record at line 260*/
    {
        CMD_GENERAL,
        (S)"highlight [bold|inverse|standout|<___>]",
        (S)"Sets the highlighting style (bold, inverse[standout], or to a given HTML tag)",
        (S)"^\\s*h(igh)?l(ight)?>\\s*(style)?\\s*(bold|inverse|standout|\\<([a-zA-Z]+)\\>)?\\s*$",
         _func31_,
    },

    /* generated from "cmds.master" record at line 266*/
    {
        CMD_GENERAL,
        (S)"Runs command only if EXPR is true.",
        (S)"if {expr} command",
        (S)"^\\s*if\\s*{([^}]*)}\\s*(.*)\\s*$",
         _func32_,
    },

    /* generated from "cmds.master" record at line 272*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*h(igh)?l(ight)?>\\s*(on|1|off|0)?\\s*$",
         _func33_,
    },

    /* generated from "cmds.master" record at line 278*/
    {
        CMD_GENERAL|CMD_ENCODING_RELATED,
        (S)"input encoding [euc|sjis]",
        (S)"report or set the input encoding-method for 8-bit bytes (JIS always OK)",
        (S)"^\\s*input\\s*(encoding)?>\\s*(euc|sjis)?\\s*$",
         _func34_,
    },

    /* generated from "cmds.master" record at line 284*/
    {
        CMD_GENERAL,
        (S)"limit [ <value> ]",
        (S)"set the maximum number of lines to print during any one command.",
        (S)"^\\s*limit\\s*(=?\\s*(\\d+))?\\s*$",
         _func35_,
    },

    /* generated from "cmds.master" record at line 290*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED,
        (S)"load [-now] \"file\"",
        (S)"load a file (and read or compute its index as needed)",
        (S)"^\\s*(fast)?load>\\s*(-?now)?\\s*(['\"]?)(.+)\\3\\s*$",
         _func36_,
    },

    /* generated from "cmds.master" record at line 296*/
    {
        CMD_GENERAL,
        (S)"log [- | [+]\"file\"]",
        (S)"log output to a file",
        (S)"^\\s*log>\\s*((-|<off>)|((<to>)?\\s*(\\+)?\\s*(['\"]?)(.+)\\6))?\\s*$",
         _func37_,
    },

    /* generated from "cmds.master" record at line 302*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"modify /regex/replace/[ig]",
        (S)"sets the modify regular expression and replacement for the selectd file.",
        (S)"^\\s*modify>\\s*(\\S)(.+)\\1(.*)\\1([ig]?)\\s*$",
         _func38_,
    },

    /* generated from "cmds.master" record at line 308*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"modify [on|1|off|0]",
        (S)"sets the modify filter on or off (for the indicated file)",
        (S)"^\\s*modify>\\s*(on|1|off|0)?\\s*$",
         _func39_,
    },

    /* generated from "cmds.master" record at line 314*/
    {
        CMD_GENERAL,
        (S)"msg ....",
        (S)"prints a message to the screen",
        (S)"^\\s*msg\\s*(.*)\\s*$",
         _func40_,
    },

    /* generated from "cmds.master" record at line 320*/
    {
        CMD_GENERAL|CMD_ENCODING_RELATED,
        (S)"output encoding [euc|sjis|jis|...]",
        (S)"report or set the output encoding-method",
        (S)"^\\s*output>\\s*(encoding>)?\\s*(euc|sjis|jis-?(78|83|90)?(-(ascii|roman))?)?((<(212|no212|hwk|nohwk|foldhwk|disp|nodisp|code|mark)>|[-,\\s]+)*)\\s*$",
         _func41_,
    },

    /* generated from "cmds.master" record at line 326*/
    {
        CMD_GENERAL,
        (S)"pager [boolean | [W x] H]",
        (S)"configure (width x height) or toggle the output pager",
        (S)"^\\s*pager>\\s*((on|1|off|0)|(([1-9]\\d*\\s*[,x])?\\s*([1-9]\\d*)))?\\s*$",
         _func42_,
    },

    /* generated from "cmds.master" record at line 332*/
    {
        CMD_GENERAL|CMD_NEEDS_SLOT,
        (S)"[local] prompt \"string\"",
        (S)"set the prompt format string",
        (S)"^\\s*local\\s*prompt>\\s*((['\"])(.+)\\2)?\\s*$",
         _func43_,
    },

    /* generated from "cmds.master" record at line 338*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*prompt>\\s*((['\"])(.+)\\2)?\\s*$",
         _func44_,
    },

    /* generated from "cmds.master" record at line 344*/
    {
        CMD_GENERAL,
        (S)"regex debug [on|1|off|0]",
        (S)"Turns regex debugging on or off, or reports current status.",
        (S)"^\\s*r(egex)?\\s*debug>\\s*(on|1|off|0)?\\s*$",
         _func45_,
    },

    /* generated from "cmds.master" record at line 350*/
    {
        CMD_GENERAL,
        (S)"saved list size [ <value> ]",
        (S)"set the number of elided lines to remember for the \"show\" command.",
        (S)"^\\s*saved?\\s*(list)?\\s*(size|len(gth)?)?\\s*(=?\\s*(\\d+))?\\s*$",
         _func46_,
    },

    /* generated from "cmds.master" record at line 356*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED,
        (S)"select [ num | name | . ]",
        (S)"sets the default file",
        (S)"^\\s*select>\\s*((\\.)|(#?\\s*(\\d+))|(([\"']?)(.+)\\6))?\\s*$",
         _func47_,
    },

    /* generated from "cmds.master" record at line 362*/
    {
        CMD_GENERAL,
        (S)"show",
        (S)"show the lines filtered by the last search, if any",
        (S)"^\\s*show\\s*$",
         cmd_show,
    },

    /* generated from "cmds.master" record at line 368*/
    {
        CMD_GENERAL,
        (S)"source \"filename\"",
        (S)"load commands from a file",
        (S)"^\\s*source>\\s*(['\"]?)(.+)\\1\\s*$",
         _func49_,
    },

    /* generated from "cmds.master" record at line 374*/
    {
        CMD_GENERAL,
        (S)"spinner [ <value> ]",
        (S)"sets the spinner to move each <value> lines checked (0 to disable)",
        (S)"^\\s*spinner\\s*(=?\\s*(\\d+))?\\s*$",
         _func50_,
    },

    /* generated from "cmds.master" record at line 380*/
    {
        CMD_GENERAL,
        (S)"stats",
        (S)"reports stats about the last search",
        (S)"^\\s*stats?\\s*$",
         cmd_stats,
    },

    /* generated from "cmds.master" record at line 386*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"tag [boolean] [\"string\"]",
        (S)"set, toggle, or report the tag for the slot.",
        (S)"^\\s*tag>\\s*(on|1|off|0)?\\s*((['\"])(.*)\\3)?\\s*$",
         _func52_,
    },

    /* generated from "cmds.master" record at line 392*/
    {
        CMD_GENERAL,
        (S)"verbose [on|1|off|0]",
        (S)"Turns verbosity on or off, or reports current status.",
        (S)"^\\s*verbose>\\s*(on|1|off|0)?\\s*$",
         _func53_,
    },

    /* generated from "cmds.master" record at line 398*/
    {
        CMD_GENERAL,
        (S)"version",
        (S)"report the version number",
        (S)"^\\s*version\\s*$",
         cmd_version,
    },

    /* generated from "cmds.master" record at line 404*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] word [on|1|off|0]",
        (S)"Turns word-preference mode on or off, or reports current status.",
        (S)"^\\s*word>\\s*(on|1|off|0)?\\s*$",
         _func55_,
    },

    /* generated from "cmds.master" record at line 410*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*word>\\s*(on|1|off|0)?\\s*$",
         _func56_,
    },

    /* generated from "cmds.master" record at line 416*/
    {
        CMD_GENERAL|CMD_LOAD_RELATED|CMD_NEEDS_SLOT,
        (S)"[default] wildcard [on|1|off|0]",
        (S)"Selects wildcard \"glob\" patterns instead of regular expression patterns.",
        (S)"^\\s*(glob|wild(card)?)>\\s*(on|1|off|0)?\\s*$",
         _func57_,
    },

    /* generated from "cmds.master" record at line 422*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*default\\s*(glob|wild(card)?)>\\s*(on|1|off|0)?\\s*$",
         _func58_,
    },

    /* generated from "cmds.master" record at line 428*/
    {
        CMD_GENERAL,
        (S)"exit|quit|bye|leave|done",
        (S)"Exits the program",
        (S)"^\\s*(exit|quit|bye|leave|done)\\s*$",
         cmd_exit,
    },

    /* generated from "cmds.master" record at line 434*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*(load|describe|source)\\s*$",
         _func60_,
    },

    /* generated from "cmds.master" record at line 440*/
    {
        CMD_GENERAL,
        (S)0,
        (S)0,
        (S)"^\\s*(default|local)?\\s*(autokana|cmdchar|debug|describe|encoding|files?|filter|fold|fuzz|help|highlight\\s*(style)?|input\\s*(encoding)?|limit|load|modify|output\\s*(encoding)?|pager|prompt|r(egex)?\\s*debug|saved?\\s*(list)?\\s*(size|len(gth)?)?|select|show|source|spinner|stats?|verbose|version|word|exit|quit|bye|leave|done|combine|combo|tag).*\\s*$",
         _func61_,
    }};
