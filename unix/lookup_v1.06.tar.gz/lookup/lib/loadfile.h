#ifndef __LOADFILE_H__ /* file wrapper */
#define __LOADFILE_H__
/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 *
 * October 1993
 *
 * Routine to load a file and to load, create, and/or write an accompaning
 * index. WRT loadfile, a "file" is a rather high-level object that has
 * an index and other substructures associated with it.
 *
 * On a lower level is "readfile" which deals with filesystem files
 * as singular enteties.
 */

#define loadfile_version 101 /* 1.01 */
#include "longlinenote.h"
#include "index.h"

/*
 * Info about a loaded file. Here, a "file" is rather high-level concept.
 */
struct fileinfo
{
    const char *filename;               /* name of file */
    const char *short_filename;         /* name of file */
    unsigned char *text;		/* pointer to text of file */
    unsigned filesize;			/* size of that text */
    const struct index *index;		/* index for file */
    const char *indexfile;              /* name of file index was read from */
    struct long_line_note *long_lines;  /* long line info */
    char file_read_complete;            /* true if text file read done */
    char index_read_complete;           /* true if index file read done */
};


/*
 * Load a named text file, and automatically load or calculate an index
 * for it. Also can write the index to a file (these options controlled
 * by the FLAGS given below).
 */
extern struct fileinfo *
    loadfile(const char *filename, unsigned percent, unsigned flags);

/* These flags must be distinct from those in index.h */
#define LOADFILE_WRITEINDEX    0x00010000
#define LOADFILE_READINDEX     0x00020000
#define LOADFILE_FAST          0x00040000
#define LOADFILE_READifPRESENT 0x00080000

/*
 * File extention expected for indexi read and written by loadfile.
 */
#define LOADFILE_INDEX_EXTENTION   ".jin" /* jeff's index */


/*
 * Given the name of a text file, return the name of its associated index
 * file (or what it would be called were it to exist). The returned string
 * should eventually be free'd by the user.
 */
extern char *indexfile_name(const char *datafile_name);

#endif /* file wrapper */
