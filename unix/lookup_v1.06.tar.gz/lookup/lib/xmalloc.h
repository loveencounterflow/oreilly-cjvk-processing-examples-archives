#ifndef __XMALLOC_H__ /* file wrapper */
#define __XMALLOC_H__

#ifdef DEBUG_MALLOC
# include <malloc.h>
# define xmalloc(foo) malloc(foo)
#else
  extern void *xmalloc(unsigned len); /* Simple "get memory or die" malloc. */
#endif

#endif /* file wrapper */
