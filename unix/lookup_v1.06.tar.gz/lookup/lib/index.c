/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 *
 * October 1993
 *
 * See comment in index.h for general info about this stuff.
 */

#include "config.h"
#include "system.h"
#include "assert.h"
#include "system.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#ifndef O_CREATE
# if defined(_HAVE_SYS_FCNTL_H_)
#   include <sys/fcntl.h>
# elif defined(_HAVE_FCNTL_H_)
#   include <fcntl.h>
# endif
#endif

#include "output.h"
#include "index.h"
#include "xmalloc.h"	/* for xmalloc () */
#include "readfile.h"
#include <ctype.h>

/*
 * Given that X of Y has been done, print what percent has been done.
 * The temp variable T is used to hold the last value printed.
 */
#define REPORT_PROGRESS(x, of, y, done, t)                                   \
macro_start {                                                                \
    int _percent = (100 * (x))/(y);                                          \
    if (_percent != (t)) {                                                   \
	outputf("index %02d%% \r", (t) = _percent);                          \
	flush_output();                                                      \
    }                                                                        \
} macro_end

/*
 * For each character (which is a HI/LO pair) of each line in all
 * FILESIZE bytes of TEXT, call enter(HI, LO, start-of-line-value).
 * PER_LINE will be done once per text line.
 */
#define SCAN_TEXT(TEXT, FILESIZE, PER_LINE, ENTER)                           \
macro_start {                                                                \
    unsigned char *ptr = (TEXT);                                             \
    unsigned char *endp = ptr + (FILESIZE);                                  \
    unsigned lastpercent = 0; /* for REPORT_PROGRESS */                      \
    unsigned char c; /* general use */                                       \
                                                                             \
    while (ptr < endp)                                                       \
    {                                                                        \
	/* "value" is what will eventually be stored in the per-char list */ \
	TextOffset value = makeTextOffset(text, ptr);                        \
                                                                             \
        if (flags & INDEX_REPORT_PROGRESS)                                   \
	   REPORT_PROGRESS(ptr - (TEXT), of, (FILESIZE), done, lastpercent); \
                                                                             \
	{ PER_LINE; }                                                        \
                                                                             \
	/* for each character (single or multibyte) in the line... */        \
	while (ptr < endp && (c = *ptr++, c != '\n'))                        \
	{                                                                    \
            if (c == 0245) {                                                 \
		/* a multibyte katakana: translate to hiragana */            \
                ENTER (0244&0x7f, *(ptr++) & 0x7f, value);                   \
	    } else if (c & 0x80) {                                           \
		/* any other multibyte */                                    \
                ENTER (c & 0x7f, *(ptr++) & 0x7f, value);                    \
	    } else if (isalnum(c)) {                                         \
		/* a regular (ASCII) alphabetic or numeric */                \
		ENTER (0, isupper(c) ? tolower(c) : c, value);               \
	    }                                                                \
	}                                                                    \
    }                                                                        \
} macro_end


/*
 * create_index(TEXT, SIZE, PER, LC)
 * Create an index for the SIZE bytes of TEXT.
 * Characters that are on at least PER percent of the lines in
 * the file are omitted from the index.
 */
struct index *
create_index(unsigned char *text, unsigned size,
	     unsigned percent, unsigned flags)
{
    unsigned hi, lo;		/* general usage for accessing index */
    struct index index;		/* real index header */
    struct index *indexp;       /* fully allocated real index pointer */
    unsigned char *freemem;     /* pointer into indexp of unpartitioned mem */

    /*
     * Before creating the real index, we'll use a temporary full
     * (i.e. non-sparse) HI/LO array index to compute some things,
     * such as how we'll sparse-ize the real index.
     */
    struct fullindex {
	struct fullindex_entry {
	    unsigned count;
	    TextOffset lastentered;
	    int mem_needed;
	    unsigned char *listptr;
	} char_info[/*high 7-bit byte*/128][/*low 7-bit byte*/128];
    } *fullindex;


    /* allocate and clear memory for fullindex -- freed at end of this fcn */
    fullindex = (void*)xmalloc(sizeof(*fullindex));
    bzero((void*)fullindex, sizeof(*fullindex));

    /*
     * Do the first scan of the text, noting how many
     * lines each character is on, and how much memory its index will need.
     */
    #define enter1(_HI_, _LO_, _DATA_)                                       \
    macro_start {                                                            \
        unsigned char HI = (_HI_);                                           \
	unsigned char LO = (_LO_);                                           \
	TextOffset DATA = (_DATA_);                                          \
	struct fullindex_entry *p = &fullindex->char_info[HI][LO];           \
	unsigned DIFF = DATA - p->lastentered;                               \
	if (DATA == 0 || DIFF) {                                             \
	    p->lastentered = DATA;                                           \
	    p->mem_needed += bytes_required_for_packed_value(DATA?DIFF:0);   \
	    p->count++;                                                      \
	}                                                                    \
    } macro_end

    index.linecount = 0;
    SCAN_TEXT(text, size, {index.linecount++;}, enter1);
    #undef enter1

    /* figure the line limiter */
    index.limitcount = index.linecount * percent / 100;
    if (index.limitcount > MAX_COUNT)
        index.limitcount = MAX_COUNT;

    /*
     * Will run through the fullindex we created and note, for each
     * character seen (i.e. for each hi/lo combo there) how much memory
     * in the index we'll need to represent it (if it's not omitted because
     * it's on too many lines).
     */
    index.indexsize = sizeof(index); /* will at least need index head */
    index.omittedsize = 0;

    for (hi = 0x00; hi < 0x80; hi++) /* for every possible HI byte.... */
    {
	/* look for the first LO with entries in it */
	for (lo = 0; lo < 0x80; lo++)
	    if (fullindex->char_info[hi][lo].count != 0)
		break;

	/* no memory needed if there are none */
	if (lo >= 0x80) {
	    index.hi[hi].first_lo = index.hi[hi].end_lo = 0;
	    continue;
	}

	/* now go through the rest of the LOs, noting the last we've seen */
	for (index.hi[hi].first_lo = lo; lo < 0x80; lo++)
	{
	    unsigned count = fullindex->char_info[hi][lo].count;
	    if (count == 0)
		continue;

	    /* note that we've seen a LO at least this late in the game */
	    index.hi[hi].end_lo = lo;

	    if (count < index.limitcount) {
		if (count != 0)
		{
		    if (flags & INDEX_REPORT_STATS)
		    {
			outputf("%d times [%c%c] %d bytes]\n", count,
			       (hi ? (hi|0x80) : ' '), (hi ? (lo|0x80) : lo),
			       fullindex->char_info[hi][lo].mem_needed);
		    }
		    index.indexsize += fullindex->char_info[hi][lo].mem_needed;
		}
	    } else {
		/* on too many lines... we'll omit this from the index */
		if (flags & INDEX_REPORT_SKIPPED)
		   outputf("[%c%c:%d/%d]",
			 (hi ? (hi|0x80) : ' '), (hi ? (lo|0x80) : lo),
			  count, fullindex->char_info[hi][lo].mem_needed);
		index.omittedsize += fullindex->char_info[hi][lo].mem_needed;
		fullindex->char_info[hi][lo].count = SKIPPED_COUNT;
		fullindex->char_info[hi][lo].mem_needed = 0;
	    }
	}

	index.hi[hi].end_lo++; /* now points just beyond last char*/
	
	/* must also account for the lo_count[] and lo[] arrays */
	index.indexsize += (index.hi[hi].end_lo - index.hi[hi].first_lo)
	             * (sizeof(elementcount) + sizeof(IndexOffset));
    }
    if (flags & INDEX_REPORT_SKIPPED)
	outchar('\n');

    indexp = xmalloc(index.indexsize);	   /* allocate memory for real index */
    *indexp = index;			   /* copy partially filled header */
    freemem = (unsigned char *)&indexp[1]; /* point to free data after head */

    /* go into the real index to create the list array holders */
    for (hi = 0x00; hi < 0x80; hi++)
    {
	if (index.hi[hi].end_lo != 0) {
	    unsigned count = index.hi[hi].end_lo - index.hi[hi].first_lo;
	    indexp->hi[hi].shifted_lo = makeIndexOffset(indexp, freemem);
	    freemem += sizeof(IndexOffset) * count;
	}
    }

    /* go into the real index to partition the count array holders */
    for (hi = 0x00; hi < 0x80; hi++)
    {
	if (index.hi[hi].end_lo != 0) {
	    unsigned count = index.hi[hi].end_lo - index.hi[hi].first_lo;
	    indexp->hi[hi].listcount = makeIndexOffset(indexp, freemem);
	    freemem += sizeof(elementcount) * count;
	}
    }

    /* go into the index to partition the list memories */
    for (hi = 0x00; hi < 0x80; hi++)
    {
	IndexOffset thisCountPtr;
	IndexOffset thisListPtr;

	if (index.hi[hi].end_lo == 0)
	    continue; /* no lists needed here */

	thisCountPtr = indexp->hi[hi].listcount;
	thisListPtr  = indexp->hi[hi].shifted_lo;

	/* for each LO that exists for this HI.... */
	for (lo = index.hi[hi].first_lo; lo < index.hi[hi].end_lo; lo++)
	{
	    /* insert count for this HI/LO  */
	    elementcount count = fullindex->char_info[hi][lo].count;
	    *realptr(indexp, thisCountPtr, elementcount *) = count;


	    /* partition memory for the list if there's a list for this pair */
	    if (count && count != SKIPPED_COUNT) {
		*realptr(indexp, thisListPtr, IndexOffset *) =
		    makeIndexOffset(indexp, freemem);
		fullindex->char_info[hi][lo].listptr = freemem;
		freemem += fullindex->char_info[hi][lo].mem_needed;
	    }

	    /* bump up count and listptr pointers for next LO */
	    thisListPtr  += sizeof(IndexOffset);
	    thisCountPtr += sizeof(elementcount);

	    /* clear this for the next runthrough */
	    fullindex->char_info[hi][lo].lastentered = 0;
	}
    }

    /* make sure it came out exactly right */
    kibishii_assert(makeIndexOffset(indexp, freemem) == index.indexsize);

    /*
     * Run through text a 2nd time, actually creating the real index.
     * This is virtually identical to the loop at the top of this function.
     */
    #define enter2(_HI_, _LO_, _DATA_)                                       \
    macro_start {                                                            \
	unsigned char HI = (_HI_);                                           \
	unsigned char LO = (_LO_);                                           \
        TextOffset DATA = (_DATA_);                                          \
	struct fullindex_entry *p = &fullindex->char_info[HI][LO];           \
	if (p->count != SKIPPED_COUNT && (DATA==0 || DATA != p->lastentered))\
	{                                                                    \
	    unsigned DIFF = DATA ? (DATA - p->lastentered) : 0;              \
	    kibishii_assert(p->count != 0);                                  \
	    kibishii_assert(DATA == 0 || DATA > p->lastentered);             \
	    kibishii_assert(p->listptr != 0);                                \
	    p->lastentered = DATA;                                           \
	    /* note that we've seen this char and used it's memory */        \
	    p->count--;                                                      \
	    p->mem_needed -= write_packed_value(&p->listptr, DIFF);          \
	    assert(p->mem_needed >= 0);                                      \
	}                                                                    \
    } macro_end

    SCAN_TEXT(text, size, /*nothing special per line*/, enter2);
    #undef enter2
    if (flags & INDEX_REPORT_PROGRESS)
	output("                      \r");

    free(fullindex);
    indexp->magic = INDEX_MAGIC;
    indexp->version_major = INDEX_VERSION_MAJOR;
    indexp->version_minor = INDEX_VERSION_MINOR;
    return indexp;
}

int write_index_file(const char *filename, const struct index *i)
{
    int fd;
    int iserror;

    if (fd = open(filename, O_WRONLY|O_CREAT|O_TRUNC, 0444), fd < 0)
	return fd;
    iserror = write(fd, (void*)i, i->indexsize) != i->indexsize;
    iserror |= close(fd) != 0;

    return iserror;
}

/*
 * If TRY is true, issue no message if file not found.
 */
struct index *read_index_file(const char *filename, int try)
{
    struct index *index = 0;
    long int size = get_filesize(filename);

    if (size < 0 && try)
	return 0;
    if (size >= 0)
	index = (void *)readfile(filename, size, sizeof(struct index));

    if (index == 0)
    {
	if (!try)
	    outputf("[open of \"%s\" failed: %n]\n", filename);
	return 0;
    }

    if (size != index->indexsize) {
	warn("<warning, index seems corrupt: size is %ld, index says %d>\n",
		size, index->indexsize);
    } else if (index->magic != INDEX_MAGIC) {
	warn("<warning, index file magic is wrong>\n");
    } else if (index->version_major != INDEX_VERSION_MAJOR) {
	warn("<warning, index version major is wrong (%d != %d)>\n",
		index->version_major, INDEX_VERSION_MAJOR);
    } else if (index->version_minor != INDEX_VERSION_MINOR) {
	warn("<warning, index version minor is wrong (%d != %d)>\n",
		index->version_minor, INDEX_VERSION_MINOR);
    }
    return index;
}

/*
 * Return true if the named file seems to be an index file.
 */
int is_index_file(const char *filename)
{
    int fd;
    struct index head;
    struct stat statbuf;
    int i = 0;

    if (fd = open(filename, 0), fd < 0)
	return 0;

    if (fstat(fd, &statbuf))
	i = read(fd, &head, sizeof(head));

    close(fd);

    if (i != sizeof(head))
	return 0;

    if (head.magic != INDEX_MAGIC)
	return 0;

    if (head.indexsize != statbuf.st_size)
	return 0;

    return 1;
}
