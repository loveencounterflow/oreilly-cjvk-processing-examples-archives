#ifndef _USING_DGUX /* DGUX has its own */
#include "xmalloc.h"
#include "strsave.h"

/* return a private copy of the given string, die if out of memory */

#ifndef strcpy
 extern char *strcpy(char *, const char *);
#endif

unsigned char *strsave(const unsigned char *str)
{
    unsigned char *ptr;
    ptr = xmalloc((unsigned)strlen((void *)str)+1);
    (void)strcpy((void *)ptr, (void *)str);
    return ptr;
}
#endif /* _USING_DGUX */
