/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 *
 * October 1993
 *
 * Routine to load a file and to load, create, and/or write an accompaning
 * index. WRT loadfile, a "file" is a rather high-level object that has
 * an index and other substructures associated with it.
 *
 * On a lower level is "readfile" which deals with filesystem files
 * as singular enteties.
 */

#include "config.h"
#include "assert.h"
#include <sys/types.h>
#include <sys/stat.h>
#include "xmalloc.h"	/* for xmalloc () */
#include "strsave.h"	/* for strsave() */
#include "system.h"
#ifndef strlen
# if defined(_HAVE_STRINGS_H_) /* might be defined in system.h */
#   include <strings.h>
# else
#   include <string.h>
#   define index strchr
#   define rindex strrchr
# endif
#endif
#include "loadfile.h"
#include "output.h"
#include "readfile.h"

/*
 * Run through the text inserting a line's length in the '\n' immediately
 * preceeding it. Lines whose length is >255 (and hence have a value that
 * can't fit in a byte) have their line/length pair saved in a linked
 * list (which is returned).
 *
 * Since the first line has no preceeding '\n', its line/length pair is
 * also put into the list.
 */
static struct long_line_note *
prep_file(unsigned char *text, unsigned filesize)
{
    const unsigned char *end_of_file_ptr = text + filesize;
    unsigned char *line_length_pointer;
    unsigned len;
    struct long_line_note *long_lines = 0;


    line_length_pointer = text; /* just remember where file starts */
    for (len = 0; text < end_of_file_ptr && *text != '\n'; text++)
	len++;
    note_long_line(&long_lines, line_length_pointer, len);

    /*
     * Note length location for next line.
     * This is here and at the end of the following loop rather than just
     * at the beginning of the following loop so that the following loop
     * is entered each time with TEXT at the start of a line (rather than
     * at the end). This will prevent the loop from executing one extra time
     * for the final file-ending newline.
     */
    line_length_pointer = text++;

    while (text < end_of_file_ptr)
    {
	unsigned char *start_of_line = text;

	/* skip to end of this line */
	while (text < end_of_file_ptr && *text != '\n')
	    text++;

	if (len = text - start_of_line, len == 0 || len > 0xff) {
	    note_long_line(&long_lines, start_of_line, len);
	    len = 0; /* marker to indicate "check notes" */
	}
	*line_length_pointer = len;     /* insert length */

        line_length_pointer = text++;   /* note len location for next line */
    }

    return long_lines;
}

/*
 * Given the name of a text file, return the name of its associated index
 * file (or what it would be called were it to exist). The returned string
 * should eventually be free'd by the user.
 */
char *indexfile_name(const char *datafile_name)
{
    char *indexname = xmalloc((unsigned)(strlen((void*)datafile_name)+
					 strlen(LOADFILE_INDEX_EXTENTION)+2));
    strcpy(indexname, datafile_name);
    strcat(indexname, LOADFILE_INDEX_EXTENTION);
    return indexname;
}

/*
 * If LOADFILE_READINDEX is set, the index is read from "FILENAME.jdx".
 * Otherwise, it is created internally.
 *
 * If LOADFILE_WRITEINDEX is set, the index is written to "FILENAME.jdx".
 *
 * It's stupid to have both LOADFILE_READINDEX and LOADFILE_WRITEINDEX set.
 */
struct fileinfo *
loadfile(const char *filename, unsigned percent, unsigned flags)
{
    struct fileinfo *info = xmalloc(sizeof(struct fileinfo));
    long int filesize;
    struct stat statbuf;

    if (stat(filename, &statbuf) < 0) {
	warn("[can't stat \"%s\": %n]\n", filename);
	return 0;
    }
    info->filesize = filesize = statbuf.st_size;

    if (info->filesize == 0)
	warn("[warning: file \"%s\" is empty]\n", filename);

    /* open file */
    if (info->text = readfile(filename, filesize, 0), info->text == 0) {
	warn("[can't open \"%s\": %n]\n", filename);
	return 0;
    }

    info->file_read_complete = info->index_read_complete = 0;

    info->long_lines = 0;
    info->filename = (const char *)strsave((const unsigned char *)filename);
    info->short_filename = (const char *)rindex((void*)info->filename, '/');
    if (info->short_filename == 0)
	info->short_filename = info->filename;
    else
	info->short_filename++; /* skip over "/" */

    if (flags & (LOADFILE_READINDEX|LOADFILE_READifPRESENT))
    {
	char *name = indexfile_name(filename);
	int just_try = flags & LOADFILE_READifPRESENT;
	if (info->index = read_index_file(name, just_try), info->index == 0)
	{
	    if (flags & LOADFILE_READifPRESENT)
	    {
		free(name);
		goto build_index;
	    }
	    warn("[error: couldn't read \"%s\": %n]\n", name);
	    free(name);
	    free(info);
	    return 0;
	}
	info->indexfile = name;
	if (info->index->st_mtime != statbuf.st_mtime) {
	    warn("<WARNING, [%s] has been updated since index was written>\n",
		filename);
	}

#ifndef __om68k__ /* bug on UNIOS-U machines */
	if (!(flags & LOADFILE_FAST))
#endif
	{
	    readfile_complete(info->index);
	    readfile_complete(info->text);
	    info->long_lines = prep_file(info->text, info->filesize);
	    info->file_read_complete = 1;
	}
	
    } else {
	struct index *Index;
      build_index:
	readfile_complete(info->text);
	info->file_read_complete = 1;
        flags |= INDEX_REPORT_PROGRESS;
	Index = create_index(info->text, info->filesize, percent, flags);
	Index->st_mtime = statbuf.st_mtime;
	info->index = Index;
	info->index_read_complete = 1;
	info->long_lines = prep_file(info->text, info->filesize);
    }

    if (flags & LOADFILE_WRITEINDEX)
    {
	char *name = indexfile_name(filename);
	if (write_index_file(name, info->index) != 0)
	{
	    warn("[error: couldn't write \"%s\": %n]\n", name);
	    free(name);
	}
	else
	{
	    warn("[wrote index file \"%s\"]\n", name);
	    info->indexfile = name;
	}
    }
    return info;
}
