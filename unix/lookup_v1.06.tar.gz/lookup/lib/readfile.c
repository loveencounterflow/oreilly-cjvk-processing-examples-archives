/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 */
#include "config.h"
#include "assert.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>

#ifndef O_CREATE
# include "system.h"
# if defined(_HAVE_SYS_FCNTL_H_)
#  include <sys/fcntl.h>
# elif defined(_HAVE_FCNTL_H_)
#  include <fcntl.h>
# endif
#endif

#include "output.h"
#include "strsave.h"
#include "xmalloc.h"
#include "input.h"

#if !defined(__GNUC__)
#  if !defined(__volatile__)
#    define __volatile__ /*nothing; for use with volatile functions */
#  endif
#  if !defined(__inline__)
#    define __inline__ /*nothing; for use with volatile functions */
#  endif
#endif

long int get_filesize(const char *filename)
{
    struct stat statbuf;
    if (stat(filename, &statbuf) < 0)
	return -1L;
    else
	return statbuf.st_size;
}

#if LAZY_READFILE

#define READFILE_BLOCKSIZE     8192
#define READFILE_NOW           0x01

static struct readfile_info
{
    struct readfile_info *next;

    const char *filename;
    unsigned len, total_read;
    unsigned char *text;
    int fd;
} *base = 0, *last = 0;

static __inline__ struct readfile_info *
new_record(const char *filename, unsigned len, int fd, unsigned char *text)
{
    struct readfile_info *new = xmalloc(sizeof(struct readfile_info));
    new->next = 0;
    new->filename = (char *)strsave((const unsigned char *)filename);
    new->len = len;
    new->total_read = 0;
    new->fd = fd;
    new->text = text;
    if (last)
	last->next = new;
    else
	base = new;
    last = new;
    return new;
}

static int read_pages(struct readfile_info *info, unsigned count, int verbose)
{
    int last_percent = 0;
    int divisor; /* "may be used uninitialized" */
    kibishii_assert(info);
    kibishii_assert(info->text);
    kibishii_assert(info->len != 0);
    kibishii_assert(info->total_read < info->len);
    kibishii_assert(count > 0);
    kibishii_assert(info->fd > 2);

    if (verbose)
    {
	divisor = info->len / 100;
	if (divisor == 0)
	    verbose = 0;
    }

    while (count && (info->total_read + READFILE_BLOCKSIZE <= info->len))
    {
	if (read(info->fd, &info->text[info->total_read], READFILE_BLOCKSIZE)
	    != READFILE_BLOCKSIZE)
	{
	    warn("[read error 1 of \"%s\": %n]", info->filename);
	    return 0;
	}
	info->total_read += READFILE_BLOCKSIZE;

	if (verbose)
	{
	    int this_percent = info->total_read / divisor;
	    if (this_percent != last_percent)
	    {
		outputf("\r[reading \"%s\", %d%% complete] ",
			info->filename, last_percent = this_percent);
		flush_output();
	    }
	}
	count--;
    }

    if (count && info->len != info->total_read)
    {
	int bytes_to_read = info->len - info->total_read;
	kibishii_assert(info->len > 0);
	if (read(info->fd, &info->text[info->total_read], bytes_to_read)
	    != bytes_to_read)
	{
	    warn("[read error 2 \"%s\": %n]", info->filename);
	    return 0;
	}
	info->total_read += bytes_to_read;
	kibishii_assert(info->total_read == info->len);
    }

    if (info->total_read == info->len)
    {
	/* Have read the file completely. */
	if (verbose)
	    outputf("\r[read of \"%s\" 100%% complete.]\n", info->filename);
	close(info->fd);
        #ifdef KIBISHII_DEBUG
	    info->fd = -1; /* for good measure */
        #endif
	return 1;
    }
    return 0;
}

unsigned char *readfile(const char *filename, unsigned len, unsigned needed)
{
    struct readfile_info *new;
    unsigned char *text;
    int fd;

    kibishii_assert(filename);
    kibishii_assert(filename[0]);

    if (fd = open(filename, O_RDONLY), fd < 0)
	return 0;

    if (len == 0)
    {
	long int filesize = get_filesize(filename);
	kibishii_assert(filesize >= 0);
	len = filesize;
    }
    if (needed > len)
	needed = len;

    #ifdef MACHxx
#if 0
	if (vm_allocate(task_self(), &text, len, 1)) {
	    warn("[bad vm_allocate for \"%s\": %n]\n", filename);
	    return 0;
	}
	if ( map_fd(fd, 0, &text, 0, len)) {
	    warn("[bad map_fd for \"%s\": %n]\n", filename);
	    return 0;
	}
#else
	if (map_fd(fd, 0, &text, 1, len)) {
	    warn("[bad map_fd for \"%s\": %n]\n", filename);
	    return 0;
	}
#endif
    #else
	{
	    text = xmalloc(len);
	}
    #endif

    new = new_record(filename, len, fd, text);

    if (needed > new->total_read)
    {
	read_pages(new, (needed+READFILE_BLOCKSIZE-1)/ READFILE_BLOCKSIZE, 0);
	kibishii_assert(needed <= new->total_read);
    }
    return text;

}

int readfile_complete(const unsigned char *text)
{
    struct readfile_info *ptr;

    for (ptr = base; ptr; ptr = ptr->next)
	if (ptr->text == text)
	{
	    if (ptr->total_read == ptr->len)
		return 1;
	    kibishii_assert(ptr->total_read < ptr->len);
	    read_pages(ptr, /* all pages */ ~0, 1);
	    return 0;
	}
    return -1; /* not found */
}

int readfile_percent_done(const unsigned char *text)
{
    struct readfile_info *ptr;

    for (ptr = base; ptr; ptr = ptr->next)
	if (ptr->text == text)
	{
	    if (ptr->total_read < ptr->len)
		return ptr->total_read * 100 / ptr->len;
	    return 100;
	}
    return -1; /* not found */
}

void readfile_readsome(void)
{
    struct readfile_info *ptr = base;
    for (ptr = base; ptr; ptr = ptr->next)
	if (ptr->total_read < ptr->len)
	{
	    read_pages(ptr, 1, 0);
	    return;
	}
    input_inactivity_function = 0;
}

#else /* LAZY_READFILE */

unsigned char *readfile(const char *filename, unsigned len, unsigned needed)
{
    unsigned char *text;
    int fd;
    int i;

    kibishii_assert(filename);
    kibishii_assert(filename[0]);

    if (fd = open(filename, O_RDONLY), fd < 0)
	return 0;

    if (len == 0)
    {
	long int filesize = get_filesize(filename);
	kibishii_assert(filesize >= 0);
	len = filesize;
    }

    text = xmalloc(len);
    if (i = read(fd, text, len), i != len)
    {
	warn("[read error of \"%s\": %n]", filename, i);
	free(text);
	return 0;
    }
    return text;
}
#endif /* LAZY_READFILE */
