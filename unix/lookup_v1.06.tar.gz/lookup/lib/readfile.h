#ifndef __READFILE_H__ /* file wrapper */
#define __READFILE_H__
/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 */

#define READFILE_BLOCKSIZE 8192
#define READFILE_DONE          0x04

extern long int get_filesize(const char *filename);
extern unsigned char *readfile(const char *filename, unsigned len,
			       unsigned needed);

#if LAZY_READFILE
 extern int readfile_complete(const unsigned char *text);
 extern void readfile_readsome(void);
 extern int readfile_percent_done(const unsigned char *text);
#else
 #define readfile_complete(foo) 1
 #define readfile_percent_done(foo) 100
#endif

#endif /* file wrapper */
