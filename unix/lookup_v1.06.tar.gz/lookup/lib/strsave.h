#ifndef __STRSAVE_H__ /* file wrapper */
#define __STRSAVE_H__
#ifdef _USING_DGUX
# include <string.h>
#else
 /* return a private copy of the given string, die if out of memory */
 extern unsigned char *strsave(const unsigned char *);
#endif
#endif /* file wrapper */
