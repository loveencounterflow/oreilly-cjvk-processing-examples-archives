#include "xmalloc.h"

#undef xmalloc

/*
 * like malloc(), but dies if memory not available.
 */
void *xmalloc(unsigned len)
{
    void *ptr;
    if (ptr = (void *)malloc(len), ptr == 0)
    {
        #define MSG "<out of memory in malloc>\n"
	write(2, MSG, sizeof(MSG)-1);
	exit(3);
    }
    return ptr;
}
