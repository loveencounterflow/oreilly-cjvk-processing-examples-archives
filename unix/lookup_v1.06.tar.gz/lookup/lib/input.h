#ifndef __INPUT_H__ /* file wrapper */
#define __INPUT_H__
/*
 * Jeffrey Friedl
 * Omron Corporation			�������ʳ���
 * Nagaokakyoshi, Japan			��617Ĺ������������
 *
 * jfriedl@nff.ncl.omron.co.jp
 *
 * This work is placed under the terms of the GNU General Purpose Licence
 * (the "GNU Copyleft").
 */
#define INPUT_BUF_SIZE 100
#define STDIN 0

extern int __input_pending__(void);
extern unsigned char next_raw_input_byte(void);
extern unsigned char next_cooked_input_byte(void);
extern int preread_input_pending;
extern int flush_pending_input(void);
extern int wait_for_input(int seconds);
extern void (*input_inactivity_function)();
extern void ensure_blocking_input(void);

#define input_pending() (preread_input_pending || __input_pending__())

#endif /* file wrapper */
