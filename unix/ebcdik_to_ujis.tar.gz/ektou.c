/***********************************************************************
			ektou.c				 ������
						89/10/31�ò�����
							 ������
	EBCDIK+KEIS����UJIS(���ܸ�EUC)�ؤ��Ѵ������Ϥ�EBCDIK+KEIS
	�Τ����Ȥ����ƥ����ȥե�����Ǥʤ���ư����ݾڤ���ʤ���
	VOS3�ǤϽ��Ϥ�MS-DOS�Ǥ����Ϥ�Х��ʥꥪ���ץ�
***********************************************************************/

/* usage:
	ektou -o[fts] [input-file [output-file]]
   ���� ektou [-fts] input-file1 input-file2 ��

	-o �ġ� ��2�����򡢽��ϥե�����Ȳ�᤹�롣
	-f �ġ� ���ϤΥХåե���󥰤򤷤ʤ���
	-t �ġ� ���Ϥ�Х��ʥ���ڤ��ؤ��ʤ������ϥ⡼�ɤ�����Ū��
		���ꤹ������Ѥ��롣VOS3�ʳ��Ǥ�̵��̣��
	-s �ġ� �Ѵ����ˡ�$�פȡ�\�פ����촹����Ԥ���
*/

#include <stdio.h>
#include <ctype.h>
#ifndef VOS3
#  include <sys/types.h>
#  include <sys/stat.h>
#endif
#ifdef MSDOS
#  include <fcntl.h>
#endif

#ifdef VOS3
#  define isascii(c) 1
#endif
#ifdef LSI_C
#  define is_xdigit(x) isxdigit(x)
#  define is_digit(c) isdigit(c)
#  define is_upper(c) isupper(c)
#else
#  define is_xdigit(x) (isascii(x) && isxdigit(x))
#  define is_digit(c) (isascii(c) && isdigit(c))
#  define is_upper(c) (isascii(c) && isupper(c))
#endif

#ifndef LSI_C
#  define fsetbin(fp) setmode(fileno(fp), O_BINARY)
#endif

#define MEMBLEN 8
#define	ERRLVL	8

int	yendol = 0;
#define	SS2	0x8E
#define is_uhank(c) (0xA1 <= (c) && (c) <= 0xFE) /* 0xFE should be 0xDF? */
#define isuhank(c) /* char c; */ is_uhank((int)(unsigned char)(c))

#define stdinsign(s) ((s) != NULL && *(s) == '-' && (s)[1] == '\0')

char	*com;

extern	char	atoektbl[][0x100];

char	*mes[] = {
	"",
	"Illegal option.",
	"Can't open input.",
	"Can't open or write to output.",
	"Too many arguments.",
#ifdef VOS3
	"Is a partitioned dataset.",
#else
	"Is a directory.",
#endif
	"Several input files couldn't be opened.",
	"Sorry, can't malloc.",
	"Can't switch to binary mode.", /* VOS3 */
};

errexit(fnm, n)
char	*fnm;
int	n;
{
	fprintf(stderr, "%s: ", com);
	fprintf(stderr, (fnm == NULL ? "" : "%s: "), fnm);
	fprintf(stderr, "%s\n", mes[n]);
#ifdef VOS3
	exit(ERRLVL);
#else
	exit(n);
#endif
}

#define	warn()								\
{									\
	fprintf(stderr, "%s: WARNING: Illegal KANJI-IN or ", com);	\
	fprintf(stderr, "KANJI-OUT sequence found in input file.\n");	\
}

#define cantmalloc() errexit((char *)NULL, 7)
#define cantbinopen() errexit((char *)NULL, 8)

#ifdef VOS3

 /* VOS3�ˤ����ơ������ǡ������å�̾��'#'�ǻ���Ǥ��롣string.hɬ�� */
FILE	*expopen(fn, s, m)
FILE	*((*fn)());
char	*s, *m;
{
	char	*buf, *p, *malloc();
	FILE	*f;

	if(*s != '#') return((*fn)(s, m));
	if(NULL == (buf = malloc(strlen(s) + 2))) errexit((char *)NULL, 7);
	p = buf;

	++s; /* skip '#' */
	*p++ = '\'';
	while(*s && *s != '/') *p++ = *s++;
	*p++ = '\'';
	while(*p++ = *s++);

	f = (*fn)(buf, m);
	free(buf);
	return(f);
}
FILE	*orgfopen(s, m) char *s, *m; {return(fopen(s, m));}
FILE	*orgpopen(s, m) char *s, *m;
	{extern FILE *popen(); return(popen(s, m));}
#define fopen(s, m) expopen(orgfopen, s, m)
#define popen(s, m) expopen(orgpopen, s, m)

FILE	*binreopen(orgf, mode)
FILE	*orgf;
char	mode;
{
	static	char	opt[ ] = "?,BINARY";

	if(isterm(orgf)) return(orgf);
	*opt = mode;
	if((orgf= freopen(NULL, opt, orgf)) == NULL) errexit((char *)NULL, 8);
	return(orgf);
}

#endif /* VOS3 */

#ifndef VOS3
#  ifndef MSDOS
isdir(fnm)
char	*fnm;
{
	struct	stat	statbuf;

	return(stat(fnm, &statbuf) == 0 &&
	       (statbuf . st_mode & S_IFMT) == S_IFDIR);
}
#  endif
#else
isdir(fnm)
char	*fnm;
{
	FILE	*f;
	char	s[MEMBLEN + 1];
	int	retval;

	if(NULL == (f = popen(fnm, "r"))) return(0);
	retval = (NULL == nextmem(s, f) || *s != '\0');
	fclose(f);
	return(retval);
}
#endif

#ifndef VOS3
#  define ctoi(c) ((c)- (is_digit(c) ? '0' : (is_upper(c) ? 'A'-10 : 'a'-10)))
#else
extern	unsigned char	cvalue[];
#  define ctoi(c) ((int)cvalue[c]) /* cvalue[] is extern */
#endif

main(ac, av)
int	ac;
char	*av[];
{
	int	flshp = -1; /* -1��̵���� 0�ĥХåե���󥰤��� 1�Ĥʤ� */
	int	c, inonly = 1, notbin = 0;
	extern	int	optind, opterr;
	extern	char	*optarg;

	com = *av;
	opterr = 0;

	while(EOF != (c = getopt(ac, av, "ofts"))){
		switch(c){
		case 'o': inonly = 0; break;
		case 'f': flshp = 1; break;
		case 't': notbin = 1; break;
		case 's': yendol = 1; break;
		default: errexit((char *)NULL, 1);
		}
	}
	if(yendol){
		tblexc(0x24, 0x5c);
	}
	
	if(inonly && ac > optind){
		FILE	*inf;
		int	erf = 0;

		if(flshp == -1) flshp = 0; /* ɸ����� */
		av += optind;
		ac -= optind;

		if(flshp) setbuf(stdout, NULL);

		while(ac--){
			if(stdinsign(*av)){
#ifdef VOS3
				if(!notbin) binreopen(stdout, 'w');
		 /* If not pertitioned, 'a' is preferrable, but we can't
		    examine whether stdout is pertitioned or not... (sigh) */
#endif
#ifdef MSDOS
				fsetbin(stdin);
#endif
				ektou(stdin, stdout);
			} else
#ifndef MSDOS
			if(isdir(*av)){
				erf |= 02;
				fprintf(stderr, "%s: %s: Is a directory.\n",
					com, *av);
			} else
#endif
			if(NULL == (inf = fopen(*av, "r"))){
				erf |= 01;
				fprintf(stderr, "%s: %s: Can't open input.\n",
					com, *av);
			} else {
#ifdef VOS3
				if(!notbin) binreopen(stdout, 'w');
#endif
#ifdef MSDOS
				fsetbin(inf);
#endif
				ektou(inf, stdout);
				fclose(inf);
			}
			av++;
		}
		if(erf) errexit((char *)NULL, 6);
	} else {
		char	*infnm, *otfnm;
		FILE	*inf, *otf;

		inf = stdin;
		otf = stdout;
		infnm = otfnm = NULL;

		av += ac;
		ac -= optind;
		while(ac--){
			switch(ac){
			case 0: infnm = *--av; break;
			case 1: otfnm = *--av; break;
			default: errexit((char *)NULL, 4);
			}
		}
		
		if(stdinsign(infnm)) inf = stdin; else if(infnm != NULL){
#ifndef MSDOS
			if(isdir(infnm)) errexit(infnm, 5);
#endif
			if(NULL == (inf = fopen(infnm, "r")))
				errexit(infnm, 2);
		}
		if(otfnm != NULL){
#ifndef MSDOS
			if(isdir(otfnm)) errexit(otfnm, 5);
#endif
			if(NULL== (otf= fopen(otfnm, "w"))) errexit(otfnm, 3);
			if(flshp == -1) flshp = 0; /* ɸ����ϰʳ� */
		} else
			if(flshp == -1) flshp = 0; /* ɸ����� */

		if(flshp) setbuf(otf, NULL);

#ifdef VOS3
		if(!notbin) binreopen(otf, 'w');
#endif
#ifdef MSDOS
		fsetbin(inf);
#endif
		ektou(inf, otf);
		fclose(inf);
		fclose(otf);
	}
	return(0);
}

#define KEISESC 0x0a
#define KEISIN2 0x42
#define KEISOT2 0x41
#define EBKSPC	0x40
#define EBKCR	0x15

#define isnotspcl(c) \
	((c) != EOF && (c) != EBKSPC && (c) != EBKCR && (c) != KEISESC)

#define eputc(c, f) \
	if(EOF == putc((c), (f))) errexit((char *)NULL, 2)

ektou(inf, otf)
register FILE	*inf, *otf;
{
	register int	c;
	int	mode = 0; /* mode 0=EBCDIK 1=KEIS */
	register char	*tbl = atoektbl[1];

	while((c = getc(inf)) != EOF){
		if(c == EBKSPC){
			eputc(tbl[c], otf);
		} else if(c == EBKCR){
			mode = 0;
			eputc(tbl[c], otf);
		} else if(c == KEISESC){
			switch(getc(inf)){
			case KEISIN2: mode = 1; break;
			case KEISOT2: mode = 0; break;
			default: /* warn() */; /* ignore it */
			}
		} else {
			switch(mode){
			case 1:
				eputc(c, otf);
				eputc(getc(inf), otf);
				 /* input isn't checked */

				while((c = getc(inf)), isnotspcl(c)){
					eputc(c, otf);
					eputc(getc(inf), otf);
					 /* input isn't checked */
				}
				if(c == EOF) return; else ungetc(c, inf);
				break;

			default:
				c = tbl[c];
				if(isuhank(c)) eputc(SS2, otf);
				eputc(c, otf);

				while((c = getc(inf)), isnotspcl(c)){
					c = tbl[c];
					if(isuhank(c))
						eputc(SS2, otf);
					eputc(c, otf);
				}
				if(c == EOF) return; else ungetc(c, inf);
			}
		}
	}
	/* �����ˤʤˤ��������դ��ä���ݤϡ�EOF����return�������ľ�� */
}

/*
atoh(s)
char	*s;
{
	int	c = 0;

	for(; is_xdigit(*s); s++){
		c <<= 4;
		c += ctoi(*s);
	}
	return(c);
}
*/

#define	touint(c) ((c) & 0xff)

tblexc(c, d)
int	c, d;
{
	char	b;

	b = atoektbl[0][c];
	atoektbl[0][c] = atoektbl[0][d];
	atoektbl[0][d] = b;

	b = atoektbl[1][touint(atoektbl[0][c])];
	atoektbl[1][touint(atoektbl[0][c])] =
		atoektbl[1][touint(atoektbl[0][d])];
	atoektbl[1][touint(atoektbl[0][d])] = b;
}
