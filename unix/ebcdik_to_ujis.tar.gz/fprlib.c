 /* LSI C-86�ѡ��񼰤�%s��%c�����Ȥ��ʤ�fprintf */
#include <stdio.h>
#include <stdarg.h>
int	fprintf(FILE *f, const char *fmt, ...)
{
	va_list	ap;
	int	retval = 0;
	union {
		char	*s;
		int	i;
	} arg1;

	va_start(ap, fmt);
	for(; *fmt; fmt++){
		if(*fmt != '%')	goto normal_out;
		switch(*++fmt){
		case 's':
			arg1 . s = va_arg(ap, char *);
			retval += strlen(arg1 . s);
			if(0 == fputs(arg1 . s, f)) continue;
			break;
		case 'c':
			arg1 . i = va_arg(ap, int);
			retval++;
			if(EOF != fputc(arg1 . i, f)) continue;
			break;
		default:
		normal_out:
			retval++;
			if(EOF != fputc(*fmt, f)) continue;
		}
		retval = -1;
		break;
	}
	va_end(ap);
	return retval;
}

#ifdef DEBUG
main()
{
	fprintf(stderr, "He%llo %s%c\n", "World", '!');
	return 0;
}
#endif
