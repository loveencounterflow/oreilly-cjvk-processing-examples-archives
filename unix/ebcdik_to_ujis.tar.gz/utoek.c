/***********************************************************************
			utoek.c				 ������
						89/10/31�ò�����
							 ������
	UJIS(���ܸ�EUC)����EBCDIK+KEIS�ؤ��Ѵ������Ϥ�UJIS��
	�����Ȥ����ƥ����ȥե�����Ǥʤ��ȷ�̤��ݾڤ���ʤ���
	VOS3�Ǥ����Ϥ�MS-DOS�ǤϽ��Ϥ�Х��ʥꥪ���ץ�
***********************************************************************/

/* usage:
	utoek -o[fnrs] [input-file [output-file]]
   ���� utoek [-fnrs] input-file1 input-file2 ��

	-o �ġ� ��2�����򡢽��ϥե�����Ȳ�᤹�롣
	-f �ġ� ���ϤΥХåե���󥰤򤷤ʤ���
	-n �ġ� ���ڡ������ϻ���EBCDIK���ڤ괹���륷�����󥹤��Ǥ���
		�ǥե���ȤǤ��Ǥ��ʤ���
	-r �ġ� �����θ�β��Ի���EBCDIK���ڤ괹���륷�����󥹤��Ǥ��ʤ���
		�ǥե���ȤǤ��Ǥ���
	-s �ġ� �Ѵ����ˡ�$�פȡ�\�פ����촹����Ԥ���
*/

#include <stdio.h>
#include <ctype.h>
#ifndef VOS3
#  include <sys/types.h>
#  include <sys/stat.h>
#endif
#ifdef MSDOS
#  include <fcntl.h>
#endif

#ifdef VOS3
#  define isascii(c) 1
#endif
#ifdef LSI_C
#  define is_xdigit(c) isxdigit(c)
#  define is_digit(c) isdigit(c)
#  define is_upper(c) isupper(c)
#else
#  define is_xdigit(c) (isascii(c) && isxdigit(c))
#  define is_digit(c) (isascii(c) && isdigit(c))
#  define is_upper(c) (isascii(c) && isupper(c))
#endif

#ifndef LSI_C
#  define fsetbin(fp) setmode(fileno(fp), O_BINARY)
#endif

#define MEMBLEN 8
#define	ERRLVL	8

#define stdinsign(s) ((s) != NULL && *(s) == '-' && (s)[1] == '\0')

int	spf = 1; /* 1��SP����Ƥ�EBCDIK���ڤ괹���ʤ� 0���ڤ괹���� */
int	ekcr = 1; /* 1�Ĵ�����β��Ԥ�EBCDIK���ڤ괹���� 0���ڤ괹���ʤ� */
int	yendol = 0;
#define	SS2	0x8E

char	*com;

extern	char	atoektbl[][0x100];

char	*mes[] = {
	"",
	"Illegal option.",
	"Can't open input.",
	"Can't open output.",
	"Too many arguments.",
#ifdef VOS3
	"Is a partitioned dataset.",
#else
	"Is a directory.",
#endif
	"Several input files couldn't be opened.",
	"Sorry, can't malloc.",
	"Can't switch to binary mode.", /* VOS3 */
};

#define cantmalloc() errexit((char *)NULL, 7)
#define cantbinopen() errexit((char *)NULL, 8)

errexit(fnm, n)
char	*fnm;
int	n;
{
	fprintf(stderr, "%s: ", com);
	fprintf(stderr, (fnm == NULL ? "" : "%s: "), fnm);
	fprintf(stderr, "%s\n", mes[n]);
#ifdef VOS3
	exit(ERRLVL);
#else
	exit(n);
#endif
}

#ifdef VOS3

 /* VOS3�ˤ����ơ������ǡ������å�̾��'#'�ǻ���Ǥ��롣string.hɬ�� */
FILE	*expopen(fn, s, m)
FILE	*((*fn)());
char	*s, *m;
{
	char	*buf, *p, *malloc();
	FILE	*f;

	if(*s != '#') return((*fn)(s, m));
	if(NULL == (buf = malloc(strlen(s) + 2))) errexit((char *)NULL, 7);
	p = buf;

	++s; /* skip '#' */
	*p++ = '\'';
	while(*s && *s != '/') *p++ = *s++;
	*p++ = '\'';
	while(*p++ = *s++);

	f = (*fn)(buf, m);
	free(buf);
	return(f);
}
FILE	*orgfopen(s, m) char *s, *m; {return(fopen(s, m));}
FILE	*orgpopen(s, m) char *s, *m;
	{extern FILE *popen(); return(popen(s, m));}
#define fopen(s, m) expopen(orgfopen, s, m)
#define popen(s, m) expopen(orgpopen, s, m)

FILE	*binreopen(orgf, mode)
FILE	*orgf;
char	mode;
{
	static	char	opt[ ] = "?,BINARY";

	if(isterm(orgf)) return(orgf);
	*opt = mode;
	if((orgf= freopen(NULL, opt, orgf)) == NULL) errexit((char *)NULL, 8);
	return(orgf);
}

#endif /* VOS3 */

#ifndef VOS3
#  ifndef MSDOS
isdir(fnm)
char	*fnm;
{
	struct	stat	statbuf;

	return(stat(fnm, &statbuf) == 0 &&
	       (statbuf . st_mode & S_IFMT) == S_IFDIR);
}
#  endif
#else
isdir(fnm)
char	*fnm;
{
	FILE	*f;
	char	s[MEMBLEN + 1];
	int	retval;

	if(NULL == (f = popen(fnm, "r"))) return(0);
	retval = (NULL == nextmem(s, f) || *s != '\0');
	fclose(f);
	return(retval);
}
#endif

#ifndef VOS3
#  define ctoi(c) ((c)- (is_digit(c) ? '0' : (is_upper(c) ? 'A'-10 : 'a'-10)))
#else
extern	unsigned char	cvalue[];
#  define ctoi(c) ((int)cvalue[c]) /* cvalue[] is extern */
#endif

main(ac, av)
int	ac;
char	*av[];
{
	int	flshp = -1; /* -1��̵���� 0�ĥХåե���󥰤��� 1�Ĥʤ� */
	int	c, inonly = 1;
	extern	int	optind, opterr;
	extern	char	*optarg;

	com = *av;
	opterr = 0;

	while(EOF != (c = getopt(ac, av, "ofnrs"))){
		switch(c){
		case 'o': inonly = 0; break;
		case 'f': flshp = 1; break;
		case 'n': spf = 0; break;
		case 'r': ekcr = 0; break;
		case 's': yendol = 1; break;
		default: errexit((char *)NULL, 1);
		}
	}
	if(yendol){
		tblexc(0x24, 0x5c);
	}

	if(inonly && ac > optind){
		FILE	*inf;
		int	erf = 0;

		if(flshp == -1) flshp = 0; /* ɸ����� */
		av += optind;
		ac -= optind;

		if(flshp) setbuf(stdout, NULL);

		while(ac--){
			if(stdinsign(*av)){
#ifdef VOS3
				binreopen(stdin, 'r');
#endif
#ifdef MSDOS
				fsetbin(stdout);
#endif
				utoek(stdin, stdout);
			} else
#ifndef MSDOS
			if(isdir(*av)){
				erf |= 02;
				fprintf(stderr, "%s: %s: Is a directory.\n",
					com, *av);
			} else
#endif
			if(NULL == (inf = fopen(*av, "r"))){
				erf |= 01;
				fprintf(stderr, "%s: %s: Can't open input.\n",
					com, *av);
			} else {
#ifdef VOS3
				binreopen(inf, 'r');
#endif
#ifdef MSDOS
				fsetbin(stdout);
#endif
				utoek(inf, stdout);
				fclose(inf);
			}
			av++;
		}
		if(erf) errexit((char *)NULL, 6);
	} else {
		char	*infnm, *otfnm;
		FILE	*inf, *otf;

		inf = stdin;
		otf = stdout;
		infnm = otfnm = NULL;

		av += ac;
		ac -= optind;
		while(ac--){
			switch(ac){
			case 0: infnm = *--av; break;
			case 1: otfnm = *--av; break;
			default: errexit((char *)NULL, 4);
			}
		}

		if(stdinsign(infnm)) inf = stdin; else if(infnm != NULL){
#ifndef MSDOS
			if(isdir(infnm)) errexit(infnm, 5);
#endif
			if(NULL == (inf = fopen(infnm, "r")))
				errexit(infnm, 2);
		}
		if(otfnm != NULL){
#ifndef MSDOS
			if(isdir(otfnm)) errexit(otfnm, 5);
#endif
			if(NULL == (otf = fopen(otfnm, "w")))
				errexit(otfnm, 3);
			if(flshp == -1) flshp = 0; /* ɸ����ϰʳ� */
		} else
			if(flshp == -1) flshp = 0; /* ɸ����� */

		if(flshp) setbuf(otf, NULL);

#ifdef VOS3
		binreopen(inf, 'r');
#endif
#ifdef MSDOS
		fsetbin(otf);
#endif
		utoek(inf, otf);
		fclose(inf);
		fclose(otf);
	}
	return(0);
}

#define UJISSPC 0x20
#define UJISCR	0x0a
#define KEISIN	"\012\102"
#define KEISOUT	"\012\101"

#define ebcdikset(otf, mode)		\
{					\
	if(mode != 0){			\
		fprintf(otf, KEISOUT);	\
		mode = 0;		\
	}				\
}

#define keisset(otf, mode)		\
{					\
	if(mode != 1){			\
		fprintf(otf, KEISIN);	\
		mode = 1;		\
	}				\
}

utoek(inf, otf)
register FILE	*inf, *otf;
{
	register int	c;
	int	mode = 0; /* 0=EBCDIK 1=KEIS */
	register char	*tbl = atoektbl[0];

	while(EOF != (c = getc(inf))){
		if(spf && c == UJISSPC){ /* space */
			putc(tbl[c], otf);

		} else if((c & 0x80) == 0){ /* ASCII, ctrl code */
			if(ekcr || c != UJISCR){
				ebcdikset(otf, mode);
			} else mode = 0;
			putc(tbl[c], otf);

			while(EOF != (c = getc(inf)) && (c & 0x80) == 0 &&
			      !(spf && c == UJISSPC)){
				putc(tbl[c], otf);
			}
			if(c == EOF) break; else ungetc(c, inf);

		} else if(c == SS2){ /* han kata */
			ebcdikset(otf, mode);
			c = getc(inf); /* input isn't checked */
			putc(tbl[c], otf);

			while(SS2 == (c = getc(inf))){
				c = getc(inf); /* input isn't checked */
				putc(tbl[c], otf);
			}
			if(c == EOF) break; else ungetc(c, inf);

		} else { /* kanji */
			keisset(otf, mode);
			putc(c, otf);
			c = getc(inf);
			putc(c, otf); /* input isn't checked */

			while(EOF != (c = getc(inf)) && (c & 0x80) &&
			      c != SS2){
				putc(c, otf);
				c = getc(inf); /* input isn't checked */
				putc(c, otf);
			}
			if(c == EOF) break; else ungetc(c, inf);
			
		}
	}

	 /* EOF���ɤ��while�롼�פ�break�����顢��������뤳�� */
	ebcdikset(otf, mode);
}

/*
atoh(s)
char	*s;
{
	int	c = 0;

	for(; is_xdigit(*s); s++){
		c <<= 4;
		c += ctoi(*s);
	}
	return(c);
}
*/

#define	touint(c) ((c) & 0xff)

tblexc(c, d)
int	c, d;
{
	char	b;

	b = atoektbl[0][c];
	atoektbl[0][c] = atoektbl[0][d];
	atoektbl[0][d] = b;

	b = atoektbl[1][touint(atoektbl[0][c])];
	atoektbl[1][touint(atoektbl[0][c])] =
		atoektbl[1][touint(atoektbl[0][d])];
	atoektbl[1][touint(atoektbl[0][d])] = b;
}
